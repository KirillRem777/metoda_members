# WordPress Members Pro - Полная документация

## 🚀 Что нового в версии 2.0

### ✨ Основные возможности
- **Таксономии для фильтрации** - Типы участников, Роли в ассоциации, Локации
- **Продвинутая страница участников** - с фильтрами, поиском и красивыми карточками
- **Персональные страницы** - детальная информация о каждом участнике
- **Встроенный импорт** - прямо из админки WordPress
- **Адаптивный дизайн** - отлично выглядит на всех устройствах

## 📁 Файлы в пакете

1. **members-management-pro.php** - основной плагин
2. **single-members.php** - шаблон персональной страницы
3. **wordpress_members_import_final.csv** - данные для импорта (27 записей)

## 📋 Пошаговая установка

### Шаг 1: Установка плагина

```bash
# Создайте папку для плагина
/wp-content/plugins/members-management-pro/

# Скопируйте туда файл
members-management-pro.php
```

Активируйте плагин через админку: **Плагины → Установленные плагины**

### Шаг 2: Установка шаблона страницы

```bash
# Скопируйте в папку вашей темы
/wp-content/themes/your-theme/single-members.php
```

### Шаг 3: Импорт данных

#### Вариант A - Через встроенный импортер (рекомендуется)

1. В админке перейдите: **Участники сообщества → Импорт из CSV**
2. Загрузите файл `wordpress_members_import_final.csv`
3. Нажмите "Импортировать"

#### Вариант B - Через WP All Import

1. Установите плагин WP All Import
2. Создайте новый импорт
3. Выберите тип записи "members"
4. Настройте соответствие полей:

```
Основные поля:
- Title → post_title
- Content → post_content
- Post Status → post_status

Custom Fields:
- member_position → Должность
- member_company → Организация
- member_location → Местоположение
- member_email → Email
- member_phone → Телефон
- member_bio → Биография
- member_specialization → Специализация
- member_experience → Опыт работы
- member_interests → Интересы

Таксономии:
- taxonomy_member_type → Тип участника
- taxonomy_member_roles → Роли (разделитель |)
- taxonomy_member_location → Локация
```

### Шаг 4: Создание страниц

#### Страница со списком участников

1. Создайте новую страницу
2. Добавьте шорткод:

```
[members_directory]
```

#### Параметры шорткода

```
[members_directory show_filters="yes" columns="3" show_search="yes"]
```

- `show_filters` - показывать фильтры (yes/no)
- `columns` - количество колонок (2/3/4)  
- `show_search` - показывать поиск (yes/no)

## 🎨 Структура данных

### Custom Post Type: members

```php
Основные поля:
- post_title         // ФИО участника
- post_content       // Описание
- post_thumbnail     // Фотография

Метаполя:
- member_position       // Должность
- member_company        // Организация
- member_specialization // Специализация
- member_experience     // Опыт работы
- member_interests      // Профессиональные интересы
- member_email         // Email
- member_phone         // Телефон
- member_linkedin      // LinkedIn
- member_website       // Вебсайт
- member_bio          // Расширенная биография
```

### Таксономии

#### member_type (Тип участника)
- Эксперт
- Участник

#### member_role (Роль в ассоциации)
- Эксперт
- Куратор секции
- Лидер проектной группы
- Амбассадор
- Почетный член
- Партнер
- Активист
- Слушатель
- Волонтер

#### member_location (Локация)
- Москва
- Санкт-Петербург
- Другие города (создаются автоматически при импорте)

## 🔧 Настройка внешнего вида

### CSS классы для кастомизации

```css
/* Общая обертка */
.members-directory-wrapper

/* Блок фильтров */
.members-filters
.filter-btn
.filter-btn.active

/* Сетка участников */
.members-grid
.member-card
.member-photo
.member-info
.member-name
.member-position
.member-company

/* Теги */
.tag
.tag-type
.tag-role

/* Персональная страница */
.member-single-wrapper
.member-hero
.member-content
.info-section
```

### Изменение цветов

Добавьте в style.css вашей темы:

```css
/* Основной цвет */
.filter-btn.active {
    background: #your-color;
    border-color: #your-color;
}

/* Градиент в шапке профиля */
.member-hero {
    background: linear-gradient(135deg, #color1 0%, #color2 100%);
}

/* Цвета тегов */
.tag-type {
    background: #e3f2fd;
    color: #1976d2;
}

.tag-role {
    background: #f3e5f5;
    color: #7b1fa2;
}
```

## 📱 Адаптивность

Система полностью адаптивна:
- **Desktop** - 3-4 колонки
- **Tablet** - 2 колонки
- **Mobile** - 1 колонка

## 🔍 JavaScript API

### Фильтрация участников

```javascript
// Программная фильтрация
function filterMembers() {
    var typeFilter = $('.filter-buttons[data-filter="member_type"] .active').data('value');
    var roleFilter = $('.filter-buttons[data-filter="member_role"] .active').data('value');
    var locationFilter = $('#location-filter').val();
    var searchTerm = $('#member-search').val();
    
    // Ваша логика фильтрации
}

// Подписка на события
$('.filter-btn').on('click', function() {
    // Обработка клика по фильтру
});
```

## 🛠 Полезные хуки

### Действия (Actions)

```php
// После сохранения участника
add_action('save_post_members', 'your_function');

// После импорта
add_action('members_after_import', 'your_function');
```

### Фильтры (Filters)

```php
// Изменение полей метабокса
add_filter('members_meta_fields', 'your_function');

// Изменение вывода карточки
add_filter('members_card_output', 'your_function');
```

## 📊 Статистика импортированных данных

- **Всего записей:** 27
- **Экспертов:** 8
- **Участников:** 19
- **С ролями:** 27
- **С локациями:** 15+

## 🆘 Решение проблем

### Не отображаются участники
1. Проверьте, активирован ли плагин
2. Сбросьте постоянные ссылки: Настройки → Постоянные ссылки → Сохранить

### Не работают фильтры
1. Убедитесь, что jQuery подключен
2. Проверьте консоль браузера на ошибки

### Проблемы с импортом
1. Убедитесь, что файл CSV в кодировке UTF-8 with BOM
2. Проверьте права на запись в БД

## 📝 Примеры использования

### Вывод только экспертов
```php
$experts = get_posts(array(
    'post_type' => 'members',
    'tax_query' => array(
        array(
            'taxonomy' => 'member_type',
            'field' => 'slug',
            'terms' => 'expert',
        ),
    ),
));
```

### Вывод по конкретной роли
```php
$curators = get_posts(array(
    'post_type' => 'members',
    'tax_query' => array(
        array(
            'taxonomy' => 'member_role',
            'field' => 'name',
            'terms' => 'Куратор секции',
        ),
    ),
));
```

## 🎯 SEO оптимизация

Плагин поддерживает:
- Schema.org разметку
- Open Graph теги
- REST API
- Sitemap XML

## 📧 Контакты и поддержка

При возникновении вопросов:
1. Проверьте эту документацию
2. Посмотрите FAQ на сайте WordPress
3. Обратитесь к разработчику темы

---

**Версия:** 2.0  
**Совместимость:** WordPress 5.0+  
**PHP:** 7.2+  
**Лицензия:** GPL v2

---

*Создано с использованием современных практик разработки для WordPress*
