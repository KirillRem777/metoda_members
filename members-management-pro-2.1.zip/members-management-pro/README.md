# Members Management Pro 2.1

<div align="center">

![Version](https://img.shields.io/badge/version-2.1-blue.svg)
![WordPress](https://img.shields.io/badge/WordPress-5.0+-green.svg)
![PHP](https://img.shields.io/badge/PHP-7.2+-purple.svg)
![License](https://img.shields.io/badge/license-GPL--2.0-orange.svg)

**Продвинутая система управления участниками и экспертами сообщества**

[Особенности](#-особенности) • [Установка](#-установка) • [Использование](#-использование) • [Changelog](#changelog) • [Поддержка](#-поддержка)

</div>

---

## 🚀 Особенности

### ✨ Основной функционал

- **Таксономии для фильтрации** - Типы участников, Роли в ассоциации, Локации
- **Продвинутая страница участников** - с AJAX фильтрами, поиском и красивыми карточками
- **Персональные страницы** - детальная информация о каждом участнике
- **Встроенный импорт** - массовая загрузка данных из CSV прямо из админки
- **Адаптивный дизайн** - отлично выглядит на всех устройствах (desktop, tablet, mobile)
- **Раздел материалов** - публикации, видео и методики для каждого участника

### 🎨 UI/UX Улучшения в версии 2.1

#### Архивная страница
- ✅ Улучшенные кнопки фильтров - неактивные серые, активные синие с белым текстом
- ✅ Исправлена позиция стрелки в выпадающих списках (город, роли)
- ✅ Полное отображение текста в должности и компании (без сокращений)
- ✅ Баджи ролей выровнены по левому краю
- ✅ Исправлена цветовая схема кнопок

#### Страница профиля
- ✅ Единообразный font-weight в текстовых блоках
- ✅ Кнопка "Отправить сообщение" в блоке контактов
- ✅ Полнофункциональные табы в разделе Материалы
- ✅ Интерактивные элементы материалов

---

## 📦 Установка

### Автоматическая установка

1. Скачайте файл `members-management-pro-2.1.zip`
2. В админ-панели WordPress перейдите: **Плагины → Добавить новый → Загрузить плагин**
3. Выберите скачанный ZIP файл
4. Нажмите **Установить** и затем **Активировать**

### Ручная установка

1. Распакуйте архив `members-management-pro-2.1.zip`
2. Загрузите папку `members-management-pro` в `/wp-content/plugins/`
3. Активируйте плагин через меню **Плагины** в WordPress

### Установка шаблона персональной страницы

Для кастомизации страниц участников:

```bash
# Скопируйте файл в папку вашей темы
cp wp-content/plugins/members-management-pro/single-members.php wp-content/themes/your-theme/
```

---

## 🎯 Использование

### Шорткод для отображения участников

Добавьте на любую страницу:

```
[members_directory]
```

### Параметры шорткода

```
[members_directory show_filters="yes" columns="3" show_search="yes"]
```

| Параметр | Значения | По умолчанию | Описание |
|----------|----------|--------------|----------|
| `show_filters` | `yes` / `no` | `yes` | Показывать фильтры |
| `columns` | `2` / `3` / `4` | `3` | Количество колонок в сетке |
| `show_search` | `yes` / `no` | `yes` | Показывать поиск |

### Примеры использования

**Простой список участников:**
```
[members_directory]
```

**Компактное отображение (4 колонки, без фильтров):**
```
[members_directory columns="4" show_filters="no"]
```

**Только эксперты (2 колонки):**
```
[members_directory columns="2" show_search="yes"]
```

---

## 📊 Импорт данных

### Через встроенный импортер (рекомендуется)

1. Перейдите: **Участники сообщества → Импорт из CSV**
2. Загрузите файл CSV (образец включен в плагин)
3. Нажмите **Импортировать**

### Формат CSV файла

Пример включен в плагин (`wordpress_members_import_final.csv`):

```csv
post_title,post_content,member_position,member_company,member_email,...
Иван Иванов,Описание участника,Директор,ООО Компания,email@example.com,...
```

**Обязательные поля:**
- `post_title` - ФИО участника
- `post_content` - Краткое описание

**Опциональные поля:**
- `member_position` - Должность
- `member_company` - Организация
- `member_email` - Email
- `member_phone` - Телефон
- `member_bio` - Расширенная биография
- `taxonomy_member_type` - Тип (Эксперт / Участник)
- `taxonomy_member_roles` - Роли (разделитель: |)
- `taxonomy_member_location` - Город

---

## 🎨 Настройка внешнего вида

### CSS классы для кастомизации

```css
/* Архивная страница */
.members-directory-wrapper    /* Общая обертка */
.members-filters              /* Блок фильтров */
.filter-btn                   /* Кнопка фильтра */
.filter-btn.active            /* Активная кнопка */
.members-grid                 /* Сетка участников */
.member-card                  /* Карточка участника */

/* Персональная страница */
.member-single-wrapper        /* Обертка профиля */
.member-hero                  /* Шапка профиля */
.member-content               /* Контент профиля */
.materials-tabs               /* Табы материалов */
.materials-tab.active         /* Активный таб */
.send-message-btn             /* Кнопка сообщения */
```

### Пример кастомизации

Добавьте в `style.css` вашей темы:

```css
/* Изменить основной цвет */
.filter-btn.active {
    background: #your-color;
    border-color: #your-color;
}

/* Изменить градиент в шапке профиля */
.member-hero {
    background: linear-gradient(135deg, #color1 0%, #color2 100%);
}
```

---

## 🔧 Для разработчиков

### WordPress хуки

**Actions (Действия):**

```php
// После сохранения участника
add_action('save_post_members', 'your_function');

// После импорта
add_action('members_after_import', 'your_function');
```

**Filters (Фильтры):**

```php
// Изменение полей метабокса
add_filter('members_meta_fields', 'your_function');

// Изменение вывода карточки
add_filter('members_card_output', 'your_function');
```

### Программная работа с участниками

**Получить всех экспертов:**

```php
$experts = get_posts(array(
    'post_type' => 'members',
    'tax_query' => array(
        array(
            'taxonomy' => 'member_type',
            'field' => 'slug',
            'terms' => 'expert',
        ),
    ),
));
```

**Получить участников по роли:**

```php
$curators = get_posts(array(
    'post_type' => 'members',
    'tax_query' => array(
        array(
            'taxonomy' => 'member_role',
            'field' => 'name',
            'terms' => 'Куратор секции',
        ),
    ),
));
```

---

## 📁 Структура файлов

```
members-management-pro/
├── members-management-pro.php     # Главный файл плагина
├── single-members.php             # Шаблон страницы участника
├── readme.txt                     # WordPress readme
├── README.md                      # Документация GitHub
├── DOCUMENTATION.md               # Полная документация
├── CHANGELOG.md                   # История изменений
├── LICENSE                        # GPL-2.0 лицензия
└── wordpress_members_import_final.csv  # Образец CSV для импорта
```

---

## 📋 Требования

- **WordPress:** 5.0 или выше
- **PHP:** 7.2 или выше
- **MySQL:** 5.6 или выше
- **jQuery:** включен в WordPress

---

## ❓ Часто задаваемые вопросы

### Не отображаются участники на странице

1. Убедитесь, что плагин активирован
2. Сбросьте постоянные ссылки: **Настройки → Постоянные ссылки → Сохранить**
3. Проверьте, что на странице есть шорткод `[members_directory]`

### Не работают фильтры

1. Убедитесь, что jQuery подключен (включен в WordPress по умолчанию)
2. Проверьте консоль браузера на ошибки JavaScript
3. Отключите другие плагины для выявления конфликтов

### Проблемы с импортом

1. Убедитесь, что файл CSV в кодировке **UTF-8 with BOM**
2. Проверьте права на запись в базу данных
3. Увеличьте лимиты PHP (memory_limit, max_execution_time)

---

## 📝 Changelog

### [2.1] - 2025-11-18

#### Добавлено
- Кнопка "Отправить сообщение" в блоке контактов
- Полнофункциональные табы в разделе Материалы
- Интерактивные элементы материалов

#### Улучшено
- Стили кнопок фильтров (серые/синие)
- Позиция стрелки в выпадающих списках
- Отображение текста в карточках (без сокращений)
- Выравнивание ролевых бейджей
- Цветовая схема кнопок
- Единообразный font-weight

### [2.0] - Initial Release
- Первый публичный релиз

Полный [CHANGELOG](CHANGELOG.md)

---

## 🤝 Поддержка

- **Документация:** См. файл [DOCUMENTATION.md](DOCUMENTATION.md)
- **Issues:** [GitHub Issues](https://github.com/yourusername/members-management-pro/issues)
- **Email:** support@metoda.ru

---

## 📄 Лицензия

Этот проект лицензирован под GPL-2.0 - см. файл [LICENSE](LICENSE) для деталей.

---

## 👨‍💻 Автор

**Metoda Association**

- Website: [https://metoda.ru](https://metoda.ru)
- GitHub: [@metodaassociation](https://github.com/metodaassociation)

---

## ⭐ Поддержите проект

Если этот плагин оказался полезным для вас, пожалуйста:

- ⭐ Поставьте звезду на GitHub
- 🐛 Сообщите об ошибках через Issues
- 💡 Предложите новые функции
- 🔀 Создайте Pull Request с улучшениями

---

<div align="center">

**Сделано с ❤️ для профессиональных сообществ и ассоциаций**

[⬆ Наверх](#members-management-pro-21)

</div>
