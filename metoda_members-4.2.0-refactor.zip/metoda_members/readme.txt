=== Metoda Members Management Pro ===
Contributors: metoda
Tags: members, community, management
Requires at least: 5.8
Tested up to: 6.4
Stable tag: 4.2.0-refactor
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Professional community members management plugin with modular OOP architecture.

== Description ==

Metoda Members Management Pro - профессиональная система управления участниками сообщества.

**Features:**
* Custom post types for members
* Gallery and portfolio management
* Private messaging system
* Admin dashboard with statistics
* 100% backward compatible

**v4.2.0-refactor highlights:**
* Modular OOP architecture
* 6 specialized classes (2,725 lines)
* Complete documentation (1,731+ lines)
* Security best practices (OWASP Top 10)
* Developer-friendly extensibility

== Installation ==

1. Upload the plugin files to `/wp-content/plugins/metoda_members/`
2. Activate the plugin through the 'Plugins' screen in WordPress
3. Configure settings under Members menu

== Changelog ==

= 4.2.0-refactor =
* Complete architectural refactoring to modular OOP
* Created 6 specialized classes for better code organization
* 100% backward compatibility maintained
* Comprehensive developer documentation
* Security improvements
* See CHANGELOG_REFACTORING.md for details

== Upgrade Notice ==

= 4.2.0-refactor =
100% backward compatible upgrade. No breaking changes. All templates and integrations continue working.
