# Metoda Community Management System

**Version:** 4.0.0 - Production Ready
**Author:** Kirill Rem
**License:** Proprietary
**Requires at least:** WordPress 5.8
**Tested up to:** WordPress 6.4
**Requires PHP:** 7.4+
**Stable tag:** 4.0.0

Полнофункциональная система управления участниками и экспертами профессионального сообщества.

---

## 🎯 Описание

**Metoda Community MGMT** - это комплексная система управления членами профессионального сообщества, включающая:

- ✅ Регистрацию с многошаговой валидацией
- ✅ Систему кодов доступа для импортированных участников
- ✅ Личные кабинеты с онбордингом для новых пользователей
- ✅ Управление материалами с WYSIWYG-редактором
- ✅ Форум в стиле Reddit с категориями и системой лайков
- ✅ Настраиваемые email-шаблоны
- ✅ Массовый CSV-импорт участников
- ✅ Кроппер фото с предпросмотром
- ✅ Гибкую систему ролей и прав доступа
- ✅ Поиск и фильтрацию участников
- ✅ Архив участников с красивой grid-системой

---

## 🚀 Быстрый старт

### Установка

1. **Загрузите плагин:**
   ```bash
   wp-content/plugins/metoda_members/
   ```

2. **Активируйте через WordPress Admin:**
   ```
   Плагины → Установленные → Metoda Community MGMT → Активировать
   ```

3. **Создайте необходимые страницы:**
   - `/member-registration/` - Регистрация участников
   - `/custom-login/` - Вход в систему
   - `/member-dashboard/` - Личный кабинет
   - `/members-archive/` - Архив участников
   - `/forum/` - Форум

4. **Настройте permalink:**
   ```
   Настройки → Постоянные ссылки → Сохранить изменения
   ```

---

## 📋 Основные возможности

### 🔐 Регистрация и Аутентификация

- **Многошаговая форма регистрации** с валидацией в реальном времени
- **Система кодов доступа** для импортированных участников (автогенерация)
- **Вход через email + пароль** или **email + код доступа**
- **Онбординг для новых пользователей** с приветствием и сменой пароля
- **Восстановление пароля** с email-уведомлениями

### 👥 Управление Участниками

- **Типы участников:** Участник, Эксперт, Менеджер, Администратор
- **Профили участников** с полной информацией:
  - ФИО, должность, компания
  - Город, телефон, email
  - Фото профиля с кроппером
  - Галерея изображений (до 10 фото)
  - Материалы (ссылки и файлы)

### 📄 Архив участников

- **Красивая grid-система** с карточками участников
- **Фильтрация:** по типу, роли, городу
- **Поиск** в реальном времени
- **Сортировка:** по дате, имени, городу
- **Пагинация** с настраиваемым количеством на странице

### 💼 Личный кабинет

#### Для участников:
- **Редактирование профиля** с автосохранением
- **Управление галереей** - загрузка, кроппинг, удаление фото
- **Управление материалами** по категориям:
  - Публикации (ссылки на статьи, блоги)
  - Видео (YouTube, Vimeo, прямые ссылки)
  - Презентации (загрузка PDF, PPT)
  - Кейсы (описание проектов с файлами)
- **Форум** - создание тем, участие в обсуждениях
- **Статистика** - просмотры профиля, активность

#### Для менеджеров:
- **Панель управления участниками**
- **Модерация статусов** (одобрить, отклонить, на модерации)
- **Массовые операции**
- **Фильтрация и поиск**

#### Для администраторов:
- **Полный доступ ко всем функциям**
- **CSV-импорт участников** с автогенерацией кодов доступа
- **Массовая рассылка email**
- **Настройка email-шаблонов**

### 💬 Форум

- **Создание тем** с категориями и тегами
- **Ответы и комментарии** с вложенностью
- **Система лайков** для тем и ответов
- **Подписки на темы** с email-уведомлениями
- **Закрепление тем** (только для администраторов)
- **Поиск и фильтрация** по категориям
- **Счетчики:** просмотры, ответы, лайки

### 📧 Email-уведомления

- **Приветственное письмо** при регистрации с кодом доступа
- **Уведомление о модерации** при изменении статуса
- **Уведомление о новых ответах** в форуме (для подписчиков)
- **Настраиваемые шаблоны** с переменными {{name}}, {{code}}, {{link}}

---

## 🛠 Технические требования

### Минимальные требования

- **WordPress:** 5.8 или выше
- **PHP:** 7.4 или выше (тестировано до PHP 8.2)
- **MySQL:** 5.6 или выше
- **Memory Limit:** 128MB (рекомендуется 256MB)
- **Max Upload Size:** 10MB (для фото и файлов)

### Рекомендации

- **WordPress:** 6.4+
- **PHP:** 8.1+
- **MySQL:** 8.0+
- **Memory Limit:** 256MB+
- **HTTPS:** Обязательно для production

---

## 📁 Структура файлов

```
metoda_members/
├── assets/
│   ├── css/                    # Стили
│   │   ├── variables.css       # Дизайн-система (70+ переменных)
│   │   ├── member-dashboard.css
│   │   ├── member-archive.css
│   │   └── member-forum.css
│   ├── js/                     # JavaScript
│   │   ├── member-manager.js   # Управление участниками
│   │   ├── member-dashboard.js # Личный кабинет
│   │   ├── member-archive.js   # Архив участников
│   │   ├── member-forum.js     # Форум
│   │   ├── photo-cropper.js    # Кроппер фото
│   │   └── modal-focus-trap.js # Accessibility для модальных окон
│   └── images/                 # Иконки и изображения
├── includes/
│   ├── class-member-dashboard.php      # Личный кабинет
│   ├── class-member-manager.php        # Админ-панель
│   ├── class-member-archive.php        # Архив участников
│   ├── class-member-forum.php          # Форум
│   ├── class-member-csv-importer.php   # CSV-импорт
│   ├── class-member-access-codes.php   # Коды доступа
│   ├── class-member-email-templates.php # Email-шаблоны
│   ├── class-member-file-manager.php   # Управление файлами
│   └── class-member-onboarding.php     # Онбординг
├── templates/
│   ├── custom-login.php        # Страница входа
│   ├── member-registration.php # Регистрация
│   ├── member-dashboard.php    # Личный кабинет
│   ├── members-archive.php     # Архив участников
│   └── dashboard-*.php         # Секции дашборда
├── members-management-pro.php  # Главный файл плагина
├── README.md                   # Документация
└── CHANGELOG.md                # История изменений
```

---

## 🎨 Дизайн-система

### CSS Variables (variables.css)

Плагин использует централизованную дизайн-систему с 70+ CSS-переменными:

```css
/* Цвета */
--color-primary: #2E466F;
--color-accent: #EF4E4C;
--color-success: #10b981;
--color-error: #ef4444;

/* Размеры */
--spacing-xs: 4px;
--spacing-sm: 8px;
--spacing-md: 16px;
--spacing-lg: 24px;

/* Типографика */
--font-family-base: 'Inter', sans-serif;
--font-size-sm: 14px;
--font-size-base: 16px;
--font-size-lg: 18px;
```

### Utility Classes

```css
/* Text Overflow */
.truncate              /* Однострочный текст с ellipsis */
.line-clamp-2          /* 2 строки с ellipsis */
.line-clamp-3          /* 3 строки с ellipsis */

/* Touch Targets (44px minimum - WCAG AA) */
.touch-target          /* min-width/height: 44px */

/* Aspect Ratios */
.aspect-square         /* 1:1 */
.aspect-video          /* 16:9 */
.aspect-portrait       /* 3:4 */

/* Word Breaking */
.word-break            /* break-word */
.word-break-all        /* break-all */

/* Accessibility */
.focus-ring            /* Видимое кольцо фокуса */
.sr-only               /* Screen reader only */
```

---

## 🔒 Безопасность

### Встроенная защита

- ✅ **Nonce verification** для всех AJAX запросов (36 проверок)
- ✅ **Sanitization** всех входных данных (115+ вызовов sanitize_*)
- ✅ **Escaping** всех выводов (esc_html, esc_attr, esc_url)
- ✅ **Prepared statements** для всех SQL запросов
- ✅ **Capability checks** для всех админ-функций
- ✅ **MIME-type validation** для загружаемых файлов
- ✅ **CSRF protection** через wp_nonce_field
- ✅ **XSS protection** через wp_kses
- ✅ **SQL injection protection** через $wpdb->prepare()

### Рекомендации по безопасности

1. **Используйте HTTPS** в production
2. **Ограничьте размер загружаемых файлов** (рекомендуется 10MB)
3. **Регулярно обновляйте WordPress и PHP**
4. **Используйте strong passwords** для админов
5. **Настройте file permissions** (644 для файлов, 755 для папок)

---

## ⚡ Производительность

### Оптимизации v4.0.0

- ✅ **AJAX timeout:** 10 секунд для всех запросов (23/23)
- ✅ **Error handlers:** 100% покрытие (23/23)
- ✅ **No console.log:** Чистый production код
- ✅ **Lazy loading:** Отложенная загрузка изображений
- ✅ **Debouncing:** Для поиска и фильтрации
- ✅ **Pagination:** Ограничение записей на странице

### Рекомендации

1. **Используйте кэширование** (WP Super Cache, W3 Total Cache)
2. **Включите GZIP compression**
3. **Используйте CDN** для статических файлов
4. **Оптимизируйте изображения** перед загрузкой
5. **Настройте object caching** (Redis, Memcached)

---

## 🌐 Совместимость

### WordPress Themes

Плагин совместим с любыми темами WordPress, которые следуют стандартам:
- ✅ Twenty Twenty-Three
- ✅ Astra
- ✅ GeneratePress
- ✅ Kadence
- ✅ OceanWP

### Популярные плагины

Тестировано и совместимо с:
- ✅ WooCommerce
- ✅ Yoast SEO
- ✅ Contact Form 7
- ✅ Advanced Custom Fields (ACF)
- ✅ WP Super Cache

---

## 🐛 Известные проблемы

### v4.0.0

- **jQuery selector caching** - не оптимизировано (запланировано на v4.1.0)
- **Assets minification** - нет минификации (запланировано на v4.1.0)

---

## 📚 Документация

### Дополнительные документы

- [CHANGELOG.md](CHANGELOG.md) - История изменений
- [JS_QUALITY_FIXES_3.7.6.md](JS_QUALITY_FIXES_3.7.6.md) - JS качество
- [VISUAL_UX_FIXES_3.7.5.md](VISUAL_UX_FIXES_3.7.5.md) - UI/UX улучшения

### Хуки и фильтры

```php
// Изменить количество участников на странице архива
add_filter('metoda_archive_per_page', function($per_page) {
    return 24; // По умолчанию 12
});

// Изменить роль по умолчанию при регистрации
add_filter('metoda_default_role', function($role) {
    return 'member'; // По умолчанию 'member'
});

// Кастомизация email-шаблона
add_filter('metoda_welcome_email_subject', function($subject) {
    return 'Добро пожаловать в Метода!';
});
```

---

## 💬 Поддержка

**Разработчик:** Kirill Rem
**Email:** support@metoda.ru
**GitHub:** [KirillRem777/metoda_members](https://github.com/KirillRem777/metoda_members)

---

## 📄 Лицензия

Proprietary License - Copyright © 2025 Metoda Community

Этот плагин является собственностью Metoda Community и не может быть использован, распространен или модифицирован без явного письменного разрешения.

---

## 🙏 Благодарности

Спасибо всем, кто помог в разработке:
- WordPress Community
- Bootstrap & Tailwind CSS
- Font Awesome Icons
- Inter Font Family

---

**СТАТУС:** ✅ PRODUCTION READY (v4.0.0)
**ПОСЛЕДНЕЕ ОБНОВЛЕНИЕ:** 21 ноября 2025
