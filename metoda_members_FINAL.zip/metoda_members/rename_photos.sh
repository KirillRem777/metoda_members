#!/bin/bash

# Скрипт для переименования фотографий участников
# Переименовывает английские названия в русские ФИО из CSV

cd "$(dirname "$0")"

# Mapping английских названий в русские ФИО
declare -A NAMES=(
    ["abramova viktoria"]="Абрамова Виктория Викторовна"
    ["alexey abolmasov"]="Аболмасов Алексей Владимирович"
    ["alexey novak"]="Новак Алексей Иванович"
    ["anuchina"]="Анучина Светлана Борисовна"
    ["bardina"]="Бардина Ольга Руководитель"
    ["borovik"]="Боровик Артём Сергеевич"
    ["chernova galina"]="Чернова Галина Александровна"
    ["dolzhenko ruslan"]="Долженко Руслан Алексеевич"
    ["fedkina"]="Федькина Ирина Владимировна"
    ["kaidalov"]="Кайдалов Лев Жоржевич"
    ["kidyaeva"]="Кидяева Галина Владимировна"
    ["konovalova"]="Коновалова Ольга Станиславовна"
    ["krivovitsina"]="Кривовицына Марина Михайловна"
    ["letyaeva"]="Летяева Ольга Валерьевна"
    ["maxim lebedev"]="Лебедев Максим Андреевич"
    ["muminov"]="Муминов Сухраб Файзуллаевич"
    ["seletski"]="Селецкий Эдуард Борисович"
    ["sosnin"]="Соснин Алексей Александрович"
    ["stepan smirnov"]="Смирнов Степан Алексеевич"
    ["volvatch"]="Наталья Игоревна Вольвач"
)

# Создаем папку photos если не существует
mkdir -p photos

# Счетчик
count=0

# Переименование фотографий
shopt -s nullglob
for file in Photos/*.jpg Photos/*.JPG Photos/*.png Photos/*.PNG; do
    if [ ! -f "$file" ]; then
        continue
    fi

    filename=$(basename "$file")
    # Убираем номер и расширение
    base=$(echo "$filename" | sed 's/[0-9]\+\.jpg$//' | sed 's/[0-9]\+\.JPG$//' | sed 's/[0-9]\+\.png$//' | sed 's/[0-9]\+\.PNG$//')

    # Получаем номер фото (1, 2, 3...)
    number=$(echo "$filename" | sed 's/.*\([0-9]\+\)\..*/\1/')

    # Получаем расширение
    ext="${filename##*.}"

    # Находим соответствующее русское имя
    russian_name=""
    for key in "${!NAMES[@]}"; do
        if [[ "$base" == "$key" ]]; then
            russian_name="${NAMES[$key]}"
            break
        fi
    done

    if [ -z "$russian_name" ]; then
        echo "⚠️  Не найдено соответствие для: $filename"
        continue
    fi

    # Переименовываем
    if [ "$number" == "1" ]; then
        # Первая фотография - главная (без номера)
        new_name="photos/${russian_name}.${ext}"
    else
        # Остальные фотографии - для галереи (с номером)
        new_name="photos/${russian_name}-${number}.${ext}"
    fi

    cp "$file" "$new_name"
    echo "✅ $filename → $(basename "$new_name")"
    ((count++))
done

echo ""
echo "📊 Переименовано фотографий: $count"
echo "📁 Все фотографии находятся в папке: photos/"
echo ""
echo "🎯 Готово! Теперь можно запускать импорт CSV"
